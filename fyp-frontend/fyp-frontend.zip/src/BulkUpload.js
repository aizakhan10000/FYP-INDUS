import { useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import Sidebar from './Screens/Sidebar';
import './css-files/Dashboard.css';; 


function UploadImages() {
  const navigate = useNavigate();
  const [selectedFiles, setSelectedFiles] = useState([]);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setSelectedFiles(files);
  };

  const handleUpload = () => {
    
    // Perform upload logic here (e.g., using fetch to send files to the server)
    console.log(selectedFiles);
    // Reset selectedFiles state after upload
    setSelectedFiles([]);
    navigate("/result");
  };

  return (
    <div className="container-fluid">
      <div className="row">
        {/* Sidebar */}
        <div className="col-md-2 p-0">
          <Sidebar />
        </div>

        {/* Main Content */}
        <div className="col-md-10">
          <div className="dashboard-container">
            {/* Header */}
            <div className="bg-primary-soft-blue text-dark text-center py-3 fade-in">
              <h1>Bulk Image Upload</h1>
            </div>

            {/* Upload Form */}
            <div className="container-fluid pt-4 fade-in">
              <div className="row">
                <div className="col-md-6 offset-md-3">
                  <div className="card">
                    <div className="card-body">
                      <h5 className="card-title">Select Images to Upload</h5>
                      <input
                        type="file"
                        className="form-control mb-3"
                        multiple
                        onChange={handleFileChange}
                      />
                      <button className="btn btn-primary" onClick={handleUpload}>
                        Upload Images
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UploadImages;
